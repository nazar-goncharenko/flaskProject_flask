import connexion
import six

from swagger_server.models.article import Article  # noqa: E501
from swagger_server import util


def add_inventory():  # noqa: E501
    """adds an inventory item

    Adds an item to the system # noqa: E501


    :rtype: None
    """
    return 'do some magic!'


def delete_article(title):  # noqa: E501
    """Delete article

    This can only be done by moderator. # noqa: E501

    :param title: The article that needs to be deleted
    :type title: str

    :rtype: None
    """
    return 'do some magic!'


def get_article_by_title(title):  # noqa: E501
    """Get article by article name

     # noqa: E501

    :param title: The name that needs to be fetched. Use user1 for testing. 
    :type title: str

    :rtype: Article
    """
    return 'do some magic!'


def search_inventory(search_string=None, skip=None, limit=None):  # noqa: E501
    """searches inventory

    By passing in the appropriate options, you can search for available inventory in the system  # noqa: E501

    :param search_string: pass an optional search string for looking up inventory
    :type search_string: str
    :param skip: number of records to skip for pagination
    :type skip: int
    :param limit: maximum number of records to return
    :type limit: int

    :rtype: None
    """
    return 'do some magic!'


def update_article(title):  # noqa: E501
    """Updated article

    This can only be done by the logged in user. # noqa: E501

    :param title: The article that need to be updated
    :type title: str

    :rtype: None
    """
    return 'do some magic!'
