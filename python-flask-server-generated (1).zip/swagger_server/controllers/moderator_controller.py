import connexion
import six

from swagger_server.models.p_article import PArticle  # noqa: E501
from swagger_server import util


def get_pending_article():  # noqa: E501
    """get list of pending article

    get pending article # noqa: E501


    :rtype: PArticle
    """
    return 'do some magic!'
