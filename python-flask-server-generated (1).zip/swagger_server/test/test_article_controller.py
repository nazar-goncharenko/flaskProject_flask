# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.article import Article  # noqa: E501
from swagger_server.test import BaseTestCase


class TestArticleController(BaseTestCase):
    """ArticleController integration test stubs"""

    def test_add_inventory(self):
        """Test case for add_inventory

        adds an inventory item
        """
        response = self.client.open(
            '/v2/article',
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_article(self):
        """Test case for delete_article

        Delete article
        """
        response = self.client.open(
            '/v2/article/{title}'.format(title='title_example'),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_article_by_title(self):
        """Test case for get_article_by_title

        Get article by article name
        """
        response = self.client.open(
            '/v2/article/{title}'.format(title='title_example'),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_search_inventory(self):
        """Test case for search_inventory

        searches inventory
        """
        query_string = [('search_string', 'search_string_example'),
                        ('skip', 1),
                        ('limit', 50)]
        response = self.client.open(
            '/v2/article',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_article(self):
        """Test case for update_article

        Updated article
        """
        response = self.client.open(
            '/v2/article/{title}'.format(title='title_example'),
            method='PUT')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
